function checkBrowserType() { 
    if((navigator.userAgent.indexOf("Opera") || navigator.userAgent.indexOf('OPR')) != -1 ) 
   {
       return 'Opera';
   }
   else if(navigator.userAgent.indexOf("Chrome") != -1 )
   {
       return 'Chrome';
   }
   else if(navigator.userAgent.indexOf("Safari") != -1)
   {
       return 'Safari';
   }
   else if(navigator.userAgent.indexOf("Firefox") != -1 ) 
   {
        return 'Firefox';
   }
   else if((navigator.userAgent.indexOf("MSIE") != -1 ) || (!!document.documentMode == true )) //IF IE > 10
   {
     return 'IE'; 
   }  
   else 
   {
      alert('unknown');
   }
}

function getBrowserName() {
    var isIE = /*@cc_on!@*/false || !!document.documentMode;
    if(!!window.opr && !!opr.addons || !!window.opera || navigator.userAgent.indexOf(' OPR/') >= 0) {
        return 'Opera'
    }

    // Firefox 1.0+
    if(typeof InstallTrigger !== 'undefined') {
        return 'Firefox'
    }

    // Safari 3.0+ "[object HTMLElementConstructor]" 
    if(/constructor/i.test(window.HTMLElement)
        || (function (p) { return p.toString() === "[object SafariRemoteNotification]"; })(!window['safari'] || (typeof safari !== 'undefined' && safari.pushNotification))) {
            return 'Safari'
    }

    // Internet Explorer 6-11
    if(/*@cc_on!@*/false || !!document.documentMode) {
        return 'IE'
    }

    // Edge 20+
    if(!isIE && !!window.StyleMedia) {
        return 'Microsoft EDGe'
    }

    // Chrome 1+
    if(!!window.chrome && !!window.chrome.webstore){
        return 'Chrome'
    }

    // Blink engine detection
    // if((isChrome || isOpera) && !!window.CSS) {
    //     return 'Blink'
    // }
}

function getClientOS() {
    let OSName = "";
    if(navigator.appVersion.indexOf("Linux")!=-1) {
        return OSName="Linux";
    }
    if(navigator.appVersion.indexOf("Win")!=-1) {
        return OSName="Windows";
    }    
    if(navigator.appVersion.indexOf("Mac")!=-1) {
        return OSName="MacOS";
    }
    if(navigator.appVersion.indexOf("X11")!=-1) {
        return OSName="UNIX";
    }
    if(navigator.appVersion.indexOf("Linux")!=-1) {
        return OSName="Linux";
    }

}
