(function($){
    //let audio = null;
    const BASE_URL = 'http://172.104.225.181:8085';
    const PERCENTAGE_OF_SONG = 0.5;
    const PRESENT = 0;
    const ABSENT = 1;
    var LOCATION_DATA = {};
    let sent = {};
    let dowloaded = {};
    let duration = {};
    let playPercent = 0.5;
    let oneSecond = 1000;
    let TYPE_DOWNLOAD = 'download'
    let TYPE_PLAY = 'play'
    $(document).ready(()=> {
        init();
        $(document).on('click', '.ghud-play-btn', handlePlayBtnClick);
        $(document).on('click', '.ghud-pause-btn', handlePauseBtnClick);
        $(document).on('mouseup', '.ghud-progressbar', handleProgressBarChange);
        $(document).on('mouseup', '.ghud-volumebar', handleVolumeBarChange);
        $(document).on('click', '.ghud-bell', (event)=> {
            let player = $(event.target).closest('.ghud-audio-player');
            let audio = getAudioPlayer(player);
            audio.volume = 0;
            player.find('.ghud-bell').addClass('ghud-hidden');
            player.find('.ghud-bell-mute').removeClass('ghud-hidden');
        });

        $(document).on('click', '.ghud-bell-mute', (event)=> {
            let player = $(event.target).closest('.ghud-audio-player');
            let audio = getAudioPlayer(player);
            audio.volume = 1;
            player.find('.ghud-bell').removeClass('ghud-hidden');
            player.find('.ghud-bell-mute').addClass('ghud-hidden');
        });
        
        $(document).on('click', '.ghud-download-btn-container, .ghud-mini-download-btn', handleDownloadBtnClick);

        //on audio ended event
        $('audio').on('ended', (event)=> {
            let player = $(event.target).closest('.ghud-audio-player');
            resetPlayer(player)
        })

        $(document).on('click', '.ghud-share-btn', (event)=> {
            //$('.ghud-share-container').removeClass('ghud-hidden')
            console.log('share');
        })

        // $(document).on('click', 'body', (event)=> {
        //     let shareContainer = $(event.target).closest('.ghud-share-container');
        //     let isShareBtn = $(event.target).closest('.ghud-share-btn').length > 0;
        //     if((shareContainer.length <= 0) && !isShareBtn) {
        //         $('.ghud-share-container').addClass('.ghud-hidden');
        //     }
        // })
    })

    function initPlayer(element) {
        let audio = getAudioPlayer(element);
        let $player = element.closest('.ghud-audio-player');
        let songDuration = audio.duration;
        let uniqueId = $player.closest('.ghud-audio-player').attr('id');
        if(songDuration <= 0 || songDuration == null) {
            sent[uniqueId] = true; // to force 
        }
        if(!duration[uniqueId]) {
            duration[uniqueId] = 0;
        }
        let lastTick = (new Date().getTime());
        let data = getSongData(element);
        data.type = 'play'
        $(audio).bind('timeupdate', ()=> {
            if(!sent[uniqueId]) {
                setTimeout(() => {
                    let currentTime = (new Date().getTime());
                    isNextTick = ((currentTime - lastTick) >= oneSecond);
                    if(isNextTick) {
                        duration[uniqueId]++;
                        lastTick = currentTime;
                        if(isSongPlayed(songDuration, duration[uniqueId])) {
                            if(!sent[uniqueId]) {
                                sendAjax(data, uniqueId, TYPE_PLAY, (result)=> {
                                    console.log(result);
                                })
                            }
                            sent[uniqueId] = true;
                        }
                    }
                }, 1000);
            }
            let s  = parseInt(audio.currentTime % 60);
            let m = parseInt((audio.currentTime) / 60) % 60;
            if(s < 10) {
                s = '0' + s;
            }
            $('#duration').html(`${m} : ${s}`);
            var minutes = Math.floor(audio.duration / 60);
            var seconds = Math.round(audio.duration - minutes * 60, 2);
            $('.ghud-progress-duration .text').html(`${m}:${s}`)
            $('.ghud-progress-length .text').html(`${minutes}:${seconds}`)
            let value = null;
            if(audio.currentTime > 0) {
                value = Math.floor((100/audio.duration) * audio.currentTime);
            }
            element.find('.ghud-progress').css('width', `${value}%`);
        })
    }

    function resetPlayer(player) {
        player.find('.ghud-progress').css('width', `0%`)
        player.find('.ghud-play-btn').removeClass('ghud-hidden');
        player.find('.ghud-pause-btn').addClass('ghud-hidden');
    }

    function handlePlayBtnClick(event) {
        let player = $(event.target).closest('.ghud-audio-player');
        player.find('.ghud-play-btn').addClass('ghud-hidden');
        player.find('.ghud-pause-btn').removeClass('ghud-hidden');
        let audio = getAudioPlayer(player);
        audio.play();
        initPlayer(player)
    }


    function handlePauseBtnClick(event) {
        let player = $(event.target).closest('.ghud-audio-player');
        player.find('.ghud-pause-btn').addClass('ghud-hidden');
        player.find('.ghud-play-btn').removeClass('ghud-hidden');
        let audio = getAudioPlayer(player);
        audio.pause();
    }

    function handleVolumeBtnClick(event) {
        let player = $(event.target).closest('.ghud-audio-player');
        let audio = getAudioPlayer(player);
        audio.volume = 0;
        closest.find('.ghud-bell').addClass('ghud-hidden');
        closest.find('.ghud-bell-mute').removeClass('ghud-hidden');
    }

    function handleProgressBarChange(event) {
        let player = $(event.target).closest('.ghud-audio-player');
        let leftOffset = event.pageX - $(this).offset().left;
        let songPercents = leftOffset / player.find('.ghud-progressbar').width();
        let audio = getAudioPlayer(player);
        audio.currentTime = songPercents * audio.duration;
    }

    function handleVolumeBarChange(event) {
        let player = $(event.target).closest('.ghud-audio-player');
        let leftOffset = event.pageX - $(this).offset().left;
        let songPercents = leftOffset / player.find('.ghud-volumebar').width();
        let value = Math.floor(songPercents*100);
        player.find('.ghud-volume').css('width', `${value}%`)
        let audio = getAudioPlayer(player);
        audio.volume = parseFloat(songPercents);
    }

    function getAudioPlayer(element) {
        return element.find('audio')[0];
    }

    function handleDownloadBtnClick(event) {
        let player = $(event.target).closest('.ghud-audio-player');
        let data = getSongData($(event.target));
        let uniqueId = $(player).attr('id');
        if(!dowloaded[uniqueId]) {
            sendAjax(data, uniqueId, TYPE_DOWNLOAD, (result)=> {
                console.log(result)
            });
            dowloaded[uniqueId] = true;
        }
        let artist = player.find('.ghud-artist').text() || '';
        let title = player.find('.ghud-title').text() || '';
        let audio = getAudioPlayer(player);
        let source = $(audio).find('source')[0];
        src = $(source).attr('src');
        let filename = `${artist}-${title}.mp3`;
        let link = document.createElement('a');
        link.setAttribute('href', src);
        link.setAttribute('download', filename)
        link.click();
    }

    function isSongPlayed(total_duration, played_duration) {
        let halfDuration = PERCENTAGE_OF_SONG * total_duration;
        if(played_duration >= halfDuration) {
            return true;
        } else {
            return false;
        }
    }

    function getSongData(element) {
        let $player = $(element).closest('.ghud-audio-player');
        let data = {};
        let title = $player.find('.ghud-title').text();
        let artist = $player.find('.ghud-artist').text();
        let songURL = $player.find('audio source').attr('src');
        let isrc = $player.find('audio source').attr('isrc');
        // data.device = null;
        data.isrc = isrc;
        data.url = songURL;
        data.website = window.location.hostname;
        data.count = 1;
        data.artiste = artist;
        data.title = title;
        data.browser = getBrowserName() || null;
        data.os = getClientOS() || null;
        if ("geolocation" in navigator){
            navigator.geolocation.getCurrentPosition(function(position){ 
                    data.location = position.coords;
                });
        }else{
            console.log("Browser doesn't support geolocation!");
        }
        return data;
        
    }

    function sendAjax(data, unique_id, type, then) {
        let url = `${BASE_URL}/click-stat`;
        ipLookUp(unique_id, type, (result)=> {
            data.location_detail = result;
            if(type == TYPE_DOWNLOAD) {
                data.type = TYPE_DOWNLOAD;
            } else if(type == TYPE_PLAY) {
                data.type = TYPE_PLAY;
            }
            console.log(data);
            $.ajax({
                url: url,
                type: 'put',
                data: JSON.stringify(data),
                dataType: 'json',
                crossDomain: true,
                contentType: 'application/json; charset=caharset',
            })
            .done((result)=> {
                then(result)
            })
            .fail((err)=> {
                setTimeout(() => {
                    if(type == 'dowloaded') {
                        downloaded[unique_id] = false;
                        
                    } else {
                        sent[unique_id] = false;
                    }
                }, 10000);
            })
        })
    }

    function showGeoLocationError(error) {
        switch(error.code) {
            case error.PERMISSION_DENIED:
                x.innerHTML = "User denied the request for Geolocation."
                break;
            case error.POSITION_UNAVAILABLE:
                x.innerHTML = "Location information is unavailable."
                break;
            case error.TIMEOUT:
                x.innerHTML = "The request to get user location timed out."
                break;
            case error.UNKNOWN_ERROR:
                x.innerHTML = "An unknown error occurred."
                break;
        }
    }

    function ipLookUp (unique_id, type,then) {
        $.ajax('http://ip-api.com/json')
            .done((response)=> {
                then(response);
            })
            .fail((data, status)=> {
                if(type == TYPE_PLAY) {
                    sent[unique_id] = false;
                } else if(type == TYPE_DOWNLOAD) {
                    downloaded[unique_id] = false;
                }
            });
    }

    function initP() {
        $('.ghud-audio-player').each(function() {
            init(this);
        });
    }

    function init() {
        $player = $('.ghud-audio-player')[0];
        let audio = $($player).find('audio')[0] || {};
        let dura = null;
        audio.onloadedmetadata = function() {
            dura = audio.duration;
            let s  = parseInt(audio.currentTime % 60) || 0;
            let m = parseInt((audio.currentTime) / 60) % 60 || 00;
            if(s < 10) {
                s = '0' + s;
            }
            $('#duration').html(`${m} : ${s}`);
            var minutes = Math.floor(audio.duration / 60) || 0;
            var seconds = Math.round(audio.duration - minutes * 60, 2) || 0;
            $('.ghud-progress-duration .text').html(`${m}:${s}`)
            $('.ghud-progress-length .text').html(`${minutes}:${seconds}`)
            let value = null;
            if(audio.currentTime > 0) {
                value = Math.floor((100/audio.duration) * audio.currentTime);
            }
        }
    }

    function setPlayedTrue(unique_id) {
        let sessionPlayedData = sessionStorage.getItem('played_history');
        if(sessionPlayedData) {
            let data = sessionPlayedData;
            data[unique_id] = PRESENT;
            sessionStorage.setItem('played_history', JSON.stringify(data));
        }
    }

    function setPlayedFalse(unique_id) {
        let sessionPlayedData = sessionStorage.getItem('played_history');
        if(sessionPlayedData) {
            let data = sessionPlayedData;
            data[unique_id] = ABSENT;
            sessionStorage.setItem('played_history', JSON.stringify(data));
        }
    }


    function getPlayedRecord() {
        let records = sessionStorage.getItem('played_history') || [];
        return records;
    }

    function getDownloadedRecord() {
        let records = sessionStorage.getItem('downloaded_history') || [];
    }
})(jQuery)