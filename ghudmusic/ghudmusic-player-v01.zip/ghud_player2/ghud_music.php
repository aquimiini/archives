<?php
/*
Plugin Name: Ghud Music
Description: ghud music plugin is a simple audio player plugin.
Version: 1.0
Author: Ghud Music
Author URI: http://URI_Of_The_Plugin_Author
License: GPL2
.
Any other notes about the plugin go here
.
*/
//check to see if shortcake is running
add_action('init', 'shortcode_ui_detection');
//init register ghud_player_shortcode
add_action('init', 'ghud_register_shortcodes'); //init ghud shortcode  

add_action( 'init', 'ghud_shortcode_ui_register' );

add_action('init', 'shortcode_ui_detection');

add_filter('acf/settings/remove_wp_meta_box', '__return_false');
function shortcode_ui_detection() {
    if( ! function_exists('shortcode_ui_register_for_shortcode')) {
        add_action('admin_notices', 'ghud_shortcode_ui_dev_notices');
    }
}

/**
 * Display an administration notice if the user can activate plugins.
 *
 * If the user can't activate plugins, then it's poor UX to show a notice they can't do anything to fix.
 *
 * @since 1.0.0
 */
function ghud_shortcode_ui_dev_notices() {
	if ( current_user_can( 'activate_plugins' ) ) {
		?>
		<div class="error message">
			<p><?php esc_html_e( 'Shortcode UI plugin must be active for Shortcode UI Example plugin to function.', 'shortcode-ui-example', 'shortcode-ui' ); ?></p>
		</div>
		<?php
	}
}

function ghud_register_shortcodes() {
    add_shortcode('ghud_music_player', 'ghud_shortcode');
}


function ghud_shortcode($atts, $content=null, $tag='') 
{
    extract(shortcode_atts([
        'file_path' => 'myalbum.mp3',
        'cover_path' => 'cover.jpg',
        'title' => 'no title',
        'artiste' => 'no artist',
        'isrc' => '1342'
    ], $atts, $content, $tag));
    $isrc = esc_html__($atts['isrc']);
    if(!isset($isrc)) {
        $isrc = 12445;
    }
    $uniqueId = uniqid($isrc);
    return '<div class="ghud-audio-player" id="'.$uniqueId.'">
                <div class="ghud-cover-wrapper">
                    <img class="ghud-cover-img" src="'.$atts['cover_path'].'"/>
                </div>
                <div class="ghud-audio-tag-wrapper">
                    <audio>
                        <source src="'.esc_html__($atts['file_path']).'" type="audio/mp3" isrc="'.esc_html__($atts['isrc']).'">
                    </audio>
                </div>
                <div class="ghud-main-container">
                    <div class="ghud-main-top">
                        <div class="ghud-song-info">
                            <marquee direction="left" width="100%">
                                <span class="ghud-title">'.esc_html__($atts['title']).'</span>
                                <span class="ghud-info-hyphen">-</span>
                                <span class="ghud-artist">'.esc_html__($atts['artiste']).'</span>
                            </marquee>
                        </div>
                        <div class="ghud-signup-container">
                            <div class="ghud-auth-status">Standard</div>
                            <div class="ghud-sign-btn-container">
                                <img class="ghud-signin-btn" src="'.plugins_url('/icons/signin.png', __FILE__).'"/>
                                <img class="ghud-signout-btn ghud-hidden" src="'.plugins_url('/icons/signout.png', __FILE__).'"/>
                            </div>
                        </div>
                    </div>
                    <div class="ghud-main-middle">
                        <div class="ghud-progressbar-container">
                            <div class="play-pause-btn-container">
                                <img class="ghud-play-btn" src="'.plugins_url('/icons/play.svg', __FILE__).'"/>
                                <img class="ghud-pause-btn ghud-hidden" src="'.plugins_url('/icons/pause.svg', __FILE__).'"/>
                            </div>
                            <div class="ghud-progressbar">
                                <div class="ghud-progress-duration">
                                    <span class="text"></span>
                                </div>
                                <div class="ghud-progress-length">
                                    <span class="text"></span>
                                </div>
                                <div class="ghud-progress"></div>
                            </div>
                        </div>
                    </div>
                    <div class="ghud-main-bottom">
                        <div class="ghud-volume-wrapper">
                            <div class="ghud-bell-container"> 
                                <img class="ghud-bell" src="'.plugins_url('/icons/speaker.svg', __FILE__).'">
                                <img class="ghud-bell-mute ghud-hidden" src="'.plugins_url('/icons/speaker-mute.svg', __FILE__).'">
                            </div>
                            <div class="ghud-volumebar-container">
                                <div class="ghud-volumebar">
                                    <div class="ghud-volume"></div>
                                </div>
                            </div>
                            <div class="ghud-share-btn-container">
                                <img class="ghud-share-btn" src="'.plugins_url('/icons/share.svg', __FILE__).'"/>
                                <div class="ghud-share-container ghud-hidden">
                                    <ul class="ghud-share-wrapper">
                                        <li>Lis</lii>
                                    </ul>
                                </div>
                            </div>
                            <div class="ghud-mini-download">
                                <div class="ghud-mini-download-btn-container">
                                    <img class="ghud-mini-download-btn" src="'.plugins_url('/icons/arrow-down.svg', __FILE__).'"/>
                                    <span class="ghud-min-download-label">Download</span>
                                </div>
                            </div>
                        </div>
                        <div class="ghud-logo-wrapper">
                            <div class="ghud-logo-div">
                                <img class="ghud-logo" src="'.plugins_url('/icons/ghudmusiclogo.png', __FILE__).'"/>
                            </div>
                            <div class="ghud-logo-partner-container">
                                <span class="ghud-logo-text">Certified Partner</span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="ghud-download-container">
                    <div class="ghud-download-btn-container">
                        <img class="ghud-download-btn" src="'.plugins_url('/icons/arrow-down.svg', __FILE__).'"/>
                        <span class="ghud-download-btn-label">Download</span>
                    </div>
                </div>
            </div>';
}

function ghud_shortcode_ui_register() {
    $fields = [
        ['label'=> 'file path', 'attr'=> 'file_path', 'type'=>'text'],
        ['label'=> 'cover thumbnail', 'attr'=> 'cover_path', 'type'=>'text'],
        ['label'=> 'artiste', 'attr'=> 'artiste', 'type'=>'text'],
        ['label'=> 'title', 'attr'=> 'title', 'type'=>'text'],
        ['label'=> 'isrc', 'attr'=> 'isrc', 'type'=>'text']
    ];
    /*
	 * Define the Shortcode UI arguments.
	 */
	$shortcode_ui_args = array(
		/*
		 * How the shortcode should be labeled in the UI. Required argument.
		 */
		'label' => esc_html__( 'GHUD music player', 'shortcode-ui-example', 'shortcode-ui' ),

		/*
		 * Include an icon with your shortcode. Optional.
		 * Use a dashicon, or full HTML (e.g. <img src="/path/to/your/icon" />).
		 */
		'listItemImage' => 'dashicons-editor-quote',
		'attrs' => $fields,
	);
    if(function_exists('shortcode_ui_register_for_shortcode')) {
        shortcode_ui_register_for_shortcode( 'ghud_music_player', $shortcode_ui_args );
    }
}


add_action('init', 'ghud_register_script');
add_action('wp_enqueue_scripts', 'ghud_enqueue_style');
function ghud_register_script() {
    wp_register_script( 'ghud_nav_check', plugins_url('/js/navigator-check.js', __FILE__), array('jquery'), '1.0.0' );
    wp_register_script( 'ghud_script', plugins_url('/js/ghud_script.js', __FILE__), array('jquery'), '1.0.0' );
    wp_register_style('ghud_style', plugins_url('/css/ghud_style.css', __FILE__), false, '1.0.0', 'all');
}
function ghud_enqueue_style(){
    wp_enqueue_script('ghud_nav_check');
    wp_enqueue_script('ghud_script');
    wp_enqueue_style( 'ghud_style' );
 }


